import React      	from "react";
import ReactDOM   	from "react-dom";
import DoctorSearch	from "./DoctorSearch.jsx";

// Parent controller for the doctor search app
;(function(){
	// find the location for the code
	var resultsLoc = document.querySelector('.js-doctor-search'),
		perPage = 10,
		comparePage = "";
	// if the location doesn't exist
	if (null === resultsLoc){
		return;
	}

	if(resultsLoc.getAttribute('data-per-page')){
		perPage = parseInt(resultsLoc.getAttribute('data-per-page'));
	}
	if(resultsLoc.getAttribute('data-compare-page')){
		comparePage = resultsLoc.getAttribute('data-compare-page');
	}

	ReactDOM.render(
		<DoctorSearch perPage={perPage} comparePage={comparePage} />,
		resultsLoc
	);

})();


//export { object };