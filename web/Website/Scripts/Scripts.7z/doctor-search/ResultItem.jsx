import React, {PropTypes}	from "react";
import DoctorBio 			from "./DoctorBio.jsx";
import ResultContact 		from "./ResultContact.jsx";
import ResultLocation 		from "./ResultLocation.jsx";
import ResultCompare		from "./ResultCompare.jsx";
import Labels				from "./Labels.js";

// list of Results
export default React.createClass({
	displayName: "ResultItem",
	propTypes: {
		data: PropTypes.shape({
			id: PropTypes.string.isRequired,
			profile: PropTypes.object.isRequired,
			locations: PropTypes.array.isRequired,
			phone: PropTypes.string.isRequired,
			appointmentLink: PropTypes.string.isRequired
		}).isRequired,
		comparePage: PropTypes.string.isRequired
	},

	getDefaultProps: function() {
		return {
			labels: {
				moreInfoLabel:"More Info",
				lessInfoLabel:"Less Info"
			}
		};
	},

	getInitialState: function() {
		return {
			expanded: false,
			moreInfoLabel: this.props.labels.moreInfoLabel
	  	};
	},

	toggleClass: function() {
		var label = !this.state.expanded ? Labels.lessInfoLabel : Labels.moreInfoLabel;

		this.setState({moreInfoLabel: label, expanded: !this.state.expanded});
	},
	render: function() {
		var parentClass = "results__item" + (this.state.expanded ? " is-expanded" : "");
		var viewMore = {label: this.state.moreInfoLabel, func: this.toggleClass};

		return (
			<div className={parentClass} data-id={this.props.data.id} >
				<div className="results__bio">
					<DoctorBio more={viewMore} data={this.props.data.profile} />
				</div>
				<div className="results__content">
					<ResultLocation data={this.props.data.locations} labels={Labels} />
					<ResultCompare id={this.props.data.id} labels={Labels} comparePage={this.props.comparePage} />
					<ResultContact phoneNum={this.props.data.phone} appointmentLink={this.props.data.appointmentLink} />
				</div>
				<ResultContact buttonColor={false} phoneNum={this.props.data.phone} appointmentLink={this.props.data.appointmentLink} />
			</div>
		);
	}
});
