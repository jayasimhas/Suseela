import React, {PropTypes}	from "react";
import CompareButton 		from "../shared/CompareButton.jsx";
import Labels				from "./Labels.js";

export default React.createClass({
	displayName: "ResultCompare",
	propTypes: {
		id: PropTypes.string.isRequired,
		comparePage: PropTypes.string.isRequired
	},

	render: function() {
		return (
			<div className="results__compare">
				<h4 className="results__label">{Labels.compareLabel}</h4>
				<CompareButton labels={Labels} id={this.props.id} />
				<a className="button button--secondary" href={this.props.comparePage}><i className="fa fa-list-ul"></i> View</a>
			</div>
		);
	}
});

