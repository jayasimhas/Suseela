
var resultsLoc = document.querySelector('.js-doctor-search');
// if the location doesn't exist
if (null !== resultsLoc){

	var labels = {
		appointmentButton: "Make An Appointment",
		appointmentCall: "or call",
		appointmentFull: "Not accepting new patients"
	};

	if(resultsLoc.getAttribute('data-add-label')){
		labels.addLabel = resultsLoc.getAttribute('data-add-label');
	}
	if(resultsLoc.getAttribute('data-remove-label')){
		labels.removeLabel = resultsLoc.getAttribute('data-remove-label');
	}
	if(resultsLoc.getAttribute('data-office-label')){
		labels.officeLabel = resultsLoc.getAttribute('data-office-label');
	}
	if(resultsLoc.getAttribute('data-compare-label')){
		labels.compareLabel = resultsLoc.getAttribute('data-compare-label');
	}
	if(resultsLoc.getAttribute('data-appointment-button')){
		labels.appointmentButton = resultsLoc.getAttribute('data-appointment-button');
	}
	if(resultsLoc.getAttribute('data-appointmnet-call')){
		labels.appointmentCall = resultsLoc.getAttribute('data-appointmnet-call');
	}
	if(resultsLoc.getAttribute('data-appointment-full')){
		labels.appointmentFull = resultsLoc.getAttribute('data-appointment-full');
	}
	if(resultsLoc.getAttribute('data-more-label')){
		labels.moreInfoLabel = resultsLoc.getAttribute('data-more-label');
	}
	if(resultsLoc.getAttribute('data-less-label')){
		labels.lessInfoLabel = resultsLoc.getAttribute('data-less-label');
	}
	if(resultsLoc.getAttribute('data-pager-label')){
		labels.pagerLabel = resultsLoc.getAttribute('data-pager-label');
	}
}

export default labels;
