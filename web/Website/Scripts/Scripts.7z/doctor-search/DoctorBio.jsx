import React, {PropTypes}	from "react";

export default React.createClass({
	displayName: "DoctorBio",
	
	propTypes: {
		more:PropTypes.shape({
			func:PropTypes.func.isRequired,
			label:PropTypes.string.isRequired
		}).isRequired,
		data: PropTypes.shape({
			link: PropTypes.string.isRequired,
			name: PropTypes.string.isRequired,
			picture: PropTypes.string.isRequired,
			specialties: PropTypes.array.isRequired
		}).isRequired
	},
	render: function() {
		return (
			<div className="doctor-bio">
				<div className="doctor-bio__image">
					<a href="#"><img src={this.props.data.picture} alt={this.props.data.name} /></a>
					<span className="doctor-bio__more" onClick={this.props.more.func}>{this.props.more.label}</span>
				</div>
				<div className="doctor-bio__info">
					<h2 className="doctor-bio__title"><a href={this.props.data.link}>{this.props.data.name}</a></h2>
					<ul className="doctor-bio__specialties">
						{this.props.data.specialties.map(function (specialty, index) { 
							return <li key={index}><a href={specialty.link}>{specialty.label}</a></li>; 
						})}
					</ul>
					<ul className="doctor-bio__rating">
						<li><i className="fa fa-star"></i></li>
						<li><i className="fa fa-star"></i></li>
						<li><i className="fa fa-star"></i></li>
						<li><i className="fa fa-star"></i></li>
						<li className="empty"><i className="fa fa-star"></i></li>
					</ul>
				</div>
			</div>
		);
	}
});

