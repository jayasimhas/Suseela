import React, {PropTypes}	from "react";
import Labels				from "./Labels.js";

export default React.createClass({
	displayName: "Pager",
	propTypes: {
		perPage: PropTypes.number.isRequired,
		firstResultNum: PropTypes.number.isRequired,
		totalResults: PropTypes.number.isRequired,
		pageChange: PropTypes.func.isRequired
	},

	getInitialState: function() {
		return {
			labels: {
				label1:"Showing",
				label2:"of",
				label3:"results"
			},
			totalPages: 1,
			currentPage: 0
		};
	},
	componentWillMount: function() {
		var newLabels = {},
			temp = Labels.pagerLabel;

		// if a label isn't received
		if(typeof(temp) === 'undefined' || temp.length === 0){
			// do nothing
			return;
		}
		// separate the labels from the value place holders
		temp = temp.split('{value}');
		// update the labels
		newLabels.label1 = temp[0];
		newLabels.label2 = temp[1];
		newLabels.label3 = temp[2];

		this.setState({labels:newLabels});

		this.componentWillReceiveProps(this.props);
	},
	componentWillReceiveProps: function(nextProps) {
		var totalPages = Math.ceil(nextProps.totalResults/nextProps.perPage),
			currentPage = (nextProps.firstResultNum-1)/nextProps.perPage;

		this.setState({totalPages:totalPages,currentPage:currentPage});
	},
	handlePageClick: function(value,event){
		event.preventDefault();
		this.props.pageChange(value * this.props.perPage + 1);
	},

	render: function() {

		let {label1, label2, label3} = this.state.labels,
			{totalPages, firstResultNum} = this.props,
			end = this.props.firstResultNum + this.props.perPage - 1,
			pageLinks = [];

		if(end > this.props.totalResults){
			end = this.props.totalResults;
		}

		for(let i=0;i<this.state.totalPages;i++){
			if(i === this.state.currentPage){
				pageLinks.push(<li key={i} className="current">{i+1}</li>);
			} else {
				pageLinks.push(<li key={i}><a href="#" onClick={this.handlePageClick.bind(this,i)}>{i+1}</a></li>);
			}
		}

		return (
			<div className="pager">
				<div className="pager__amount">{label1} {firstResultNum}-{end} {label2} {totalPages} {label3}</div>
				<ul className="pager__pagination">
					{ (this.state.currentPage > 0)
						? <li><a href="#"><span className="element-invisible">Prev</span> <i className="fa fa-angle-left"></i></a></li>
						: null }
					{pageLinks}
					{ (this.state.currentPage < this.state.totalPages-1)
						? <li><a href="#"><span className="element-invisible">Next</span> <i className="fa fa-angle-right"></i></a></li>
						: null }
				</ul>
			</div>
		);
	}
});

