import React, {PropTypes}	from "react";
import Results 				from "./ResultItems.jsx";
import Pager 				from "./Pager.jsx";
import $					from "jquery";

// list of Results
export default React.createClass({
	displayName: "DoctorSearch",
	propTypes: {
		perPage: PropTypes.number.isRequired,
		comparePage: PropTypes.string.isRequired
	},

	getInitialState: function() {
		return {
			data: [],
			firstResultNum: 1,
			totalResults: 0,
		};
	},
	fetchResults: function(){
		var start = this.state.firstResultNum,
			end = start + this.props.perPage - 1;

		$.ajax({
			url: "/api/search/doctors/get",
			cache: false,
			data: {start: start, end: end}
		})
		.done((jsonData, textStatus, jqXHR) => {
			this.setState({
				data: jsonData.results, 
				totalResults:jsonData.totalResults
			});
		})
		.fail((jqXHR, textStatus, errorThrown) => {
			console.error("Error loading json", jqXHR);
		});
	},
	pageChange: function(start) {
		// update start number without triggering a render
		this.state.firstResultNum = start;
		// fetch new results
		this.fetchResults();
	},
	componentWillMount: function() {
		this.fetchResults();
	},
	render: function() {
		return (
			<section>
				<Pager 
					perPage={this.props.perPage} 
					firstResultNum={this.state.firstResultNum}
					totalResults={this.state.totalResults}
					pageChange={this.pageChange} />
				<Results 
					labels={this.props.labels} 
					data={this.state.data}
					comparePage={this.props.comparePage} />
				<Pager 
					perPage={this.props.perPage} 
					firstResultNum={this.state.firstResultNum}
					totalResults={this.state.totalResults}
					pageChange={this.pageChange} />
			</section>
		);
	}
});
