import React, {PropTypes}	from "react";
import Result 				from "./ResultItem.jsx";


// list of Results
export default React.createClass({
	displayName: "ResultList",
	propTypes: {
		data: PropTypes.array.isRequired,
		comparePage: PropTypes.string.isRequired
	},

	render: function() {
		return (
			<div className="results">
				{this.props.data.map((result,index) => { return <Result key={index} data={result} comparePage={this.props.comparePage} />} )}
			</div>
		);
	}
});
