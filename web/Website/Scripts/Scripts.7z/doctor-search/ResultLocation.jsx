import React, {PropTypes}	from "react";

export default React.createClass({
	displayName: "ResultLocation",
	propTypes: {
		data: PropTypes.array.isRequired
	},
	getDefaultProps: function() {
		return {
			labels: {
				officeLabel: "Office Locations"
			}
		};
	},
	render: function() {
		return (
			<div className="results__locations">
				<h4 className="results__label">{this.props.labels.officeLabel}</h4>
				<ul className="results__locations__list">
					{this.props.data.map(function (location,index) { 
						return <li key={index}><a href={location.link}>{location.label}</a></li>; 
					})}
				</ul>
			</div>
		);
	}
});

