import React, {PropTypes}	from "react";
import Labels				from "./Labels.js";

export default React.createClass({
	displayName: "ResultContact",
	propTypes: {
		phoneNum: PropTypes.string.isRequired,
		buttonColor: PropTypes.bool,
		appointmentLink: PropTypes.string.isRequired
	},

	getDefaultProps: function() {
		return {
			buttonColor: true
		};
	},

	formatPhone: function(phone) {
		// insert a dot four in from the end
		if(phone.length === 10){
			return [phone.slice(-10, -7), ".", phone.slice(-7, -4), ".", phone.slice(-4)].join('');
		}
		return phone;
	},

	render: function() {
		if(this.props.phoneNum === ""){
			return (
				<div className="results__contact inactive">
					<span className="inactive__text">{Labels.appointmentFull}</span>
				</div>
			);
		} else {
			let phoneNum = this.formatPhone(this.props.phoneNum),
				phoneLink = "tel:+" + this.props.phoneNum
			return (
				<div className="results__contact">
					<a className={this.props.buttonColor ? 'button' : 'button button--white'} href={this.props.appointmentLink}>{Labels.appointmentButton}</a>
					<span className="tel">{Labels.appointmentCall} <a href={phoneLink}>{phoneNum}</a></span>
				</div>
			);
		}
	}
});

