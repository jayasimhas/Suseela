(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _jquery = (typeof window !== "undefined" ? window['jQuery'] : typeof global !== "undefined" ? global['jQuery'] : null);

var _jquery2 = _interopRequireDefault(_jquery);

var _removeCookieJs = require("./removeCookie.js");

var _removeCookieJs2 = _interopRequireDefault(_removeCookieJs);

"use strict";

// Compare Doctors - remove doctor from list
function removeCompareDoctor() {
	// when a remove doctor button is clicked
	(0, _jquery2["default"])('.js-remove-doctor').on('click', function (event) {
		event.preventDefault();
		var $el = (0, _jquery2["default"])(this),
		    // record the current element
		id = $el.data('doctor-id'),
		    // get the ID of the doctor
		$parents = (0, _jquery2["default"])('.js-doctor-object[data-doctor-id="' + id + '"]'); // find the parent rows

		// remove the row
		$parents.fadeOut('slow');
		// remove the doctor's id from the cookie
		(0, _removeCookieJs2["default"])('doctorCompare', id);
	});
}

// calculate the distance from our location to a specified lat and lngg coordinate
function distancefromHere() {
	(0, _jquery2["default"])('.js-distance-from-here').each(function () {
		var lat = (0, _jquery2["default"])(this).data('lat'),
		    lng = (0, _jquery2["default"])(this).data('lng'),
		    distance = undefined,
		    $el = (0, _jquery2["default"])(this);

		// if lat and lng are not found
		if (typeof lat === "undefined" || lat.length === 0 || typeof lng === "undefined" || lng.length === 0) {
			// do nothing
			return;
		}

		getDistance(lat, lng).then(function (distance) {
			$el.text(parseInt(distance) + " miles");
		})["catch"](function (err) {
			console.log(err.message);
		});
	});
}
// Google webfont loader
function loadFonts() {
	var wf = document.createElement('script'),
	    scripts = document.scripts[0];

	// Set the fonts to load
	window.WebFontConfig = {
		google: {
			families: ['Montserrat:400,700:latin', 'Roboto:400,400italic,700,700italic,300italic,300:latin', 'Arvo::latin']
		}
	};
	// Add the Google Fonts JS file
	wf.src = '//ajax.googleapis.com/ajax/libs/webfont/1.5.18/webfont.js';
	scripts.parentNode.insertBefore(wf, scripts);
}
// jQuery DotDotDot truncation
function truncate() {
	// for every truncated item on the page
	(0, _jquery2["default"])('.js-truncate').each(function () {
		var $el = (0, _jquery2["default"])(this);
		// apply the truncated class to the element
		$el.parent().addClass('is-truncated');
		// apply dotdotdot to the element
		$el.dotdotdot({
			watch: true,
			callback: function callback(isTruncated, orgContent) {
				if (isTruncated) {
					$el.parent().find('.js-untruncate').show();
				} else {
					$el.parent().find('.js-untruncate').hide();
				}
			}
		});
		// bind a click event to undo this
		$el.parent().on('click', '.js-untruncate', function () {
			$el.parent().removeClass('is-truncated');
			$el.trigger("destroy");
			// remove this link from the content
			(0, _jquery2["default"])(this).remove();
		});
	});
}

function newsletterForm() {
	var emailRegx = /.+?@.+?[.].+/;

	// for each newsletter form on the page
	(0, _jquery2["default"])('.js-newsletter-form').each(function () {
		var $el = (0, _jquery2["default"])(this),
		    $input = (0, _jquery2["default"])(this).find('input'),
		    $button = (0, _jquery2["default"])(this).find('button'),
		    id = $el.data('id'),
		    successMessage = $el.data('success'),
		    timer = undefined;

		// When the user starts typing
		$input.on('keyup', function () {
			// record what the user has entered
			var value = (0, _jquery2["default"])(this).val();
			// prevent previous data validation
			window.clearTimeout(timer);
			// if the field is empty
			if (value.length === 0) {
				// reset the flags and exit
				$el.removeClass('is-valid is-invalid');
				return;
			}
			// when the user pauses typing
			timer = setTimeout(function () {
				// validation the entered value
				test(value);
			}, 600);
		});
		// When the user submits the form
		$button.on('click', function () {
			var _this = this;

			// record what the user has entered
			var value = $input.val();
			// prevent previous data validation
			window.clearTimeout(timer);
			// if the user hasn't entered an email
			if (!test(value)) {
				// do nothing
				return;
			}
			// prevent the user from submitting another email
			(0, _jquery2["default"])(this).prop("disabled", true);
			$input.prop("disabled", true);
			// reset the flags
			$el.removeClass('is-valid is-invalid');
			// send the value to the api
			fetch('/api/mailchimp/post/' + id + '/' + value, { method: 'POST' }).then(function (response) {
				// if the request was successful
				if (response.statusText === "OK") {
					// show the success flag
					$el.addClass('is-valid');
					// display the success message and slowly fade it out
					$input.val(successMessage).css({ 'transition': 'color 10s', 'color': '#444' });
					// After the message has faded
					setTimeout(function () {
						// reset the input value
						value = "";
						$input.val(value).removeAttr('style').prop("disabled", false);
						// reactivate the button
						(0, _jquery2["default"])(_this).prop("disabled", false);
						// reset the flags
						$el.removeClass('is-valid is-invalid');
					}, 10000);
				} else {
					// show the failed flag
					$el.addClass('is-invalid');
					// reactivate the button
					(0, _jquery2["default"])(_this).prop("disabled", false);
				}
			})["catch"](function (e) {
				console.log('fetch failed', e);
			});
		});

		function test(value) {
			// if the user has entered an email
			if (emailRegx.test(value)) {
				// show the success flag
				$el.removeClass('is-invalid').addClass('is-valid');
				return true;
			}
			// otherwise show the failed flag
			$el.removeClass('is-valid').addClass('is-invalid');
			return false;
		}
	});
}

/* *********** PUBLIC Functions ************************* */

// return the distance in miles from the current location to the desired location
function getDistance(lat1, lng1) {
	return new Promise(function (resolve, reject) {
		var dist = 0;

		if (navigator.geolocation) {
			// appears to be async.
			navigator.geolocation.getCurrentPosition(function success(position) {
				//http://www.geodatasource.com/developers/javascript
				var lat2 = position.coords.latitude,
				    lng2 = position.coords.longitude,
				    radlat1 = Math.PI * lat1 / 180,
				    radlat2 = Math.PI * lat2 / 180,
				    radlng1 = Math.PI * lng1 / 180,
				    radlng2 = Math.PI * lng2 / 180,
				    theta = lng1 - lng2,
				    radtheta = Math.PI * theta / 180;

				dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
				dist = Math.acos(dist);
				dist = dist * 180 / Math.PI;
				dist = dist * 60 * 1.1515;
				resolve(dist);
			}, function error(error) {
				reject(new Error("location data incorrect"));
			});
		} else {
			reject(new Error("Geolocation not supported"));
		}
	});
}

function init() {
	// get the google webFonts
	loadFonts();
	truncate();
	distancefromHere();
	removeCompareDoctor();
	newsletterForm();
}

exports["default"] = {
	init: init,
	getDistance: getDistance
};
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./removeCookie.js":4}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});
function initMap() {
	var googleMap = document.querySelectorAll('.js-gmap');

	var _loop = function (i) {
		var element = googleMap[i],
		    lat = element.getAttribute('data-lat'),
		    lng = element.getAttribute('data-lng'),
		    canvas = element.querySelectorAll('.js-gmap-canvas')[0],
		    infoWindowHtml = element.querySelectorAll('.js-gmap-info-window')[0].innerHTML,
		    myOptions = {},
		    map = undefined,
		    marker = undefined,
		    infowindow = undefined;

		myOptions = {
			zoom: 15,
			center: new google.maps.LatLng(lat, lng),
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};

		map = new google.maps.Map(canvas, myOptions);
		marker = new google.maps.Marker({ map: map, position: new google.maps.LatLng(lat, lng) });
		infowindow = new google.maps.InfoWindow({ content: infoWindowHtml });
		google.maps.event.addListener(marker, "click", function () {
			infowindow.open(map, marker);
		});
	};

	for (var i = 0; i < googleMap.length; i++) {
		_loop(i);
	}
}
function addGoogleMapJS() {
	var scriptTag = document.createElement('script'),
	    scripts = document.scripts[0];

	// Add the Google Maps API JS file
	scriptTag.src = '//maps.google.com/maps/api/js?sensor=false';
	scriptTag.onload = function () {
		return initMap();
	};
	scripts.parentNode.insertBefore(scriptTag, scripts);
}

function init() {
	var googleMap = document.querySelector('.js-gmap');

	if (null === googleMap) {
		return;
	}

	addGoogleMapJS();
}

exports['default'] = {
	init: init
};
module.exports = exports['default'];

},{}],3:[function(require,module,exports){
/**
 * @file
 * @preserve A JavaScript file to append classes based on viewport scroll.
 *
 * @copyright Copyright (c) 2015 Palantir.net
 */

"use strict";

;(function ($) {
    "use strict";

    $(document).ready(function () {

        ////////////////////////////////////////////////
        // Trigger Select2
        ////////////////////////////////////////////////

        $("select.select2").select2();
        $("select.select2-multi").select2();

        ////////////////////////////////////////////////
        // Add and remove class for active location
        ////////////////////////////////////////////////

        $(".list__item--location").click(function () {
            $(this).addClass("active");
            $(this).siblings(".list__item").removeClass("active");
        });

        ////////////////////////////////////////////////
        // Add placeholder text to fields IE9 and below
        ////////////////////////////////////////////////

        $("input, textarea").placeholder();

        ////////////////////////////////////////////////
        // Add wrapping class around tables
        ////////////////////////////////////////////////

        // This should be targeted at RTE tables and not any table on the site. - Jonathan
        // $( ".l-block table" ).wrap( "<div class='table-wrap'></div>" );

        ////////////////////////////////////////////////
        // Toggle more office addresses
        ////////////////////////////////////////////////

        $(".profile-offices .view-offices").click(function () {
            $(this).toggleClass("open");
            $(this).text(function (i, text) {
                return text === "View fewer offices " ? "View more offices " : "View fewer offices ";
            });
            $(this).siblings(".profile-offices__all").slideToggle();
        });

        ////////////////////////////////////////////////
        // Add class to odd element in list block full
        ////////////////////////////////////////////////

        $(".list--block--full .list__item:odd").addClass("odd");

        ///////////////////////////////////////////
        // Styleguide code view toggle
        ///////////////////////////////////////////

        $(".view-code > .view-code__link").click(function () {
            $(this).toggleClass("open");
            $(this).siblings("pre").slideToggle("fast");
        });

        ///////////////////////////////////////////
        // Doctor profile tab interface
        ///////////////////////////////////////////

        $(".toggle-content").each(function () {
            var wrapper = $(this);

            var hasTabs = wrapper.hasClass("tabs");
            var startOpen = wrapper.hasClass("open");

            var dl = wrapper.children(".tabs-wrap:first");
            var dts = dl.children(".tab");
            var panes = dl.children(".tab-container");
            var groups = new Array(dts, panes);

            // Create a ul for tabs if necessary.
            if (hasTabs) {
                var ul = $("<ul class='toggle-tabs'></ul>");
                dts.each(function () {
                    var dt = $(this);
                    var li = $("<li></li>");
                    li.html(dt.html());
                    ul.append(li);
                });
                ul.insertBefore(dl);
                var lis = ul.children();
                groups.push(lis);
            }

            // Add "last" classes.
            var i;
            for (i = 0; i < groups.length; i++) {
                groups[i].filter(":last").addClass("last");
            }

            function toggleClasses(clickedItem, group) {
                var index = group.index(clickedItem);
                var i;
                for (i = 0; i < groups.length; i++) {
                    groups[i].removeClass("current");
                    groups[i].eq(index).addClass("current");
                }
            }

            // Toggle on tab (.tab) click.
            dts.on("click", function () {
                toggleClasses($(this), dts);
            });

            // Toggle on tab (li) click.
            if (hasTabs) {
                lis.on("click", function (event) {
                    toggleClasses($(this), lis);
                    event.preventDefault();
                });

                // Open the first tab.
                lis.eq(0).trigger("click");
            }

            // Open the first accordion if desired.
            if (startOpen) {
                dts.eq(0).trigger("click");
            }
        });

        ///////////////////////////////////////////
        // Search results toggle
        ///////////////////////////////////////////

        $(".content-type__menu-toggle").click(function () {
            $(this).siblings(".search-content-type").slideToggle();
            $(this).toggleClass("open");
        });

        ///////////////////////////////////////////
        // Location nav
        ///////////////////////////////////////////

        $(".location--nav__menu-toggle").click(function () {
            $(this).siblings(".location--nav__parent").slideToggle();
        });

        $(".location--nav__parent > li").hover(function () {
            $(this).toggleClass("location--nav-active");
        });

        $(".location--nav__parent .has-children").append("<i class='fa fa-angle-down'></i>");
        $(".location--nav__parent .has-children i").click(function () {

            // Only trigger if screen size is smaller than 900px
            if ($(window).width() < 900) {
                $(this).toggleClass("opened");
                $(this).siblings(".location--nav__level2").slideToggle();
            }
        });

        function accessibleLocationNav() {
            var el = $(".location--nav");

            // Make dropdown menus keyboard accessible
            $("a", el).focus(function () {
                $(this).parents("li").addClass("location--nav-active");
            }).blur(function () {
                $(this).parents("li").removeClass("location--nav-active");
            });
        }

        // Run keyboard controls for location nav
        accessibleLocationNav();

        ///////////////////////////////////////////
        // Fadeout filter tags
        ///////////////////////////////////////////

        $(".filter-tag i").click(function () {
            $(this).parent(".filter-tag").fadeOut();
        });

        ///////////////////////////////////////////
        // Toggle more filters
        ///////////////////////////////////////////

        $(".button--more-options").click(function () {
            $(this).parent(".form-view-filters").siblings(".form-more-options").slideToggle();
            $(this).html(function (i, html) {
                return html === '<i class="fa fa-chevron-down"></i> View Filters' ? '<i class="fa fa-chevron-up"></i> Hide Filters' : '<i class="fa fa-chevron-down"></i> View Filters';
            });
        });

        ///////////////////////////////////////////
        // Trigger FitVids on body tag
        ///////////////////////////////////////////

        $("body").fitVids();

        ///////////////////////////////////////////
        // Toggle doctors results info
        ///////////////////////////////////////////

        $(".results__item__more-link").click(function () {
            $(this).parent(".results__item__img").siblings(".results__item__more-info").slideToggle();

            // Toggle text in link
            if ($(this).text() === "More Info") {
                $(this).text("Less Info");
            } else {
                $(this).text("More Info");
            }
        });

        ///////////////////////////////////////////
        // Set min height for certain elements
        ///////////////////////////////////////////

        $(".callout, .list--featured-hero .list__item").matchHeight({
            byRow: true,
            property: "min-height",
            remove: false
        });

        ///////////////////////////////////////////
        // Appointment slideshow
        ///////////////////////////////////////////

        $(".appointment-form").flexslider({
            animation: "slide",
            manualControls: ".appointment-nav li",
            controlsContainer: ".appointment__buttons",
            prevText: "Previous Step",
            nextText: "Next Step",
            useCSS: false,
            animationLoop: false,
            slideshow: false,
            smoothHeight: true,
            before: function before() {
                $(".appointment__buttons .flex-nav-submit").removeClass("active");
            },
            end: function end() {
                $(".appointment__buttons .flex-nav-submit").addClass("active");
            }
        });

        // Add markup and classes to appointment nav
        $(".appointment__buttons .flex-prev").prepend("<i class='fa fa-angle-left'></i> ").addClass("button button--secondary button--large");
        $(".appointment__buttons .flex-next").append(" <i class='fa fa-angle-right'></i>").addClass("button button--large");
        $(".appointment__buttons .flex-direction-nav").append("<li class='flex-nav-submit'><a class='button button--large' href='javascript:void(0);'>Submit Appointment</a></li>");

        ///////////////////////////////////////////
        // Spotlight slideshow
        ///////////////////////////////////////////

        $(".spotlight").flexslider({
            animation: "slide",
            slideshow: false
        });

        ///////////////////////////////////////////
        // Sidebar proximity nav toggle
        ///////////////////////////////////////////

        $(".prox-nav__level2 .has-children > a").after("<i tabindex='0' class='fa fa-angle-down'></i>");

        $(".prox-nav__level2 .has-children i").focus(function () {
            $(this).toggleClass("opened");
            $(this).siblings(".prox-nav__level3").slideToggle();
        });

        $(".prox-nav__level2 .has-children i").click(function () {
            // Remove :focus on i tag when it is clicked
            $(this).blur();
        });
        // expand third level tier if active
        $(".prox-nav__level3 .is-active").closest(".prox-nav__level2").find("i").addClass("opened").siblings(".prox-nav__level3").slideDown();

        ///////////////////////////////////////////
        // Header mega menu toggle
        ///////////////////////////////////////////

        $(".site-header--nav li a, .site-header--large .button--appointment").click(function (event) {
            var $this = $(this);

            $(".bg-overlay").addClass("active");

            if ($this.data("clicked", true).hasClass("active")) {
                $this.toggleClass("active");
                $(".site-header__dropdowns__item").removeClass("active");
                $(".bg-overlay").removeClass("active");
            } else {

                // Check if the tabs menu has active class
                $(".site-header--nav li a").removeClass("active");
                $this.addClass("active");

                // Display active tab
                var currentTab = $(this).attr("href");
                $(".site-header__dropdowns__item").removeClass("active");
                $(currentTab).addClass("active");
            }
            event.preventDefault();
        });

        ///////////////////////////////////////////
        // Mobile I"d like to toggle
        ///////////////////////////////////////////

        $(".button--like-to").click(function () {

            if ($(this).hasClass("active")) {
                $(this).removeClass("active");
                $(".like-to").removeClass("active");
                $(".bg-overlay").removeClass("active");
            } else {
                $(this).addClass("active");
                $(".like-to").addClass("active");
                $(".button--search--small, .search--small").removeClass("active");
                $(".bg-overlay").addClass("active");
            }
        });

        ///////////////////////////////////////////
        // Mobile search toggle
        ///////////////////////////////////////////

        $(".button--search--small").click(function () {

            if ($(this).hasClass("active")) {
                $(this).removeClass("active");
                $(".search--small").removeClass("active");
                $(".bg-overlay").removeClass("active");
            } else {
                $(this).addClass("active");
                $(".search--small").addClass("active");
                $(".button--like-to, .like-to").removeClass("active");
                $(".bg-overlay").addClass("active");
            }
        });

        ///////////////////////////////////////////
        // Mobile overlay display
        ///////////////////////////////////////////

        $(".bg-overlay").click(function () {

            // Close mega menu
            $(".site-header--nav li a, .site-header__dropdowns__item").removeClass("active");

            // Close mobile I"d like menu
            $(".button--like-to, .like-to").removeClass("active");

            // Close mobile search
            $(".button--search--small, .search--small").removeClass("active");

            // Fade out overlay
            $(this).removeClass("active");
        });

        ///////////////////////////////////////////
        // Show health system stats on page scroll
        ///////////////////////////////////////////
        $(".js-fadeInElement").each(function () {
            var $el = $(this);

            // is the page scrollable
            if ($('body').innerHeight() > window.innerHeight) {
                fadeElement($el);
            }
            $(window).scroll(function () {
                fadeElement($el);
            });
            function fadeElement($el) {
                var elementTopToPageTop = $el.offset().top;
                var windowTopToPageTop = $(window).scrollTop();
                var windowInnerHeight = window.innerHeight;
                var elementTopToWindowTop = elementTopToPageTop - windowTopToPageTop;
                var elementTopToWindowBottom = windowInnerHeight - elementTopToWindowTop;
                var distanceFromBottomToAppear = 300;

                if (elementTopToWindowBottom > distanceFromBottomToAppear) {
                    $el.addClass("health-system__stats--show");
                } else if (elementTopToWindowBottom < 0) {
                    $el.removeClass("health-system__stats--show");
                    $el.addClass("health-system__stats--hide");
                }
            }
        }); // End show health sytem stats
    });
})(jQuery);

},{}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});
exports['default'] = removeCookieValue;

function removeCookieValue(name, value) {
	// get the current value of the cookie
	var cookieValues = Cookies.get(name) || "";
	// split the value of the cookie
	cookieValues = cookieValues.split(',');
	// search through the values
	// return all values that don't match
	cookieValues = cookieValues.filter(function (item) {
		return item !== value;
	});
	// set the cookie to the new value
	Cookies.set(name, cookieValues.join(','), { path: '/' });
}

module.exports = exports['default'];

},{}],5:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

exports["default"] = _react2["default"].createClass({
	displayName: "DoctorBio",

	propTypes: {
		more: _react.PropTypes.shape({
			func: _react.PropTypes.func.isRequired,
			label: _react.PropTypes.string.isRequired
		}).isRequired,
		data: _react.PropTypes.shape({
			link: _react.PropTypes.string.isRequired,
			name: _react.PropTypes.string.isRequired,
			picture: _react.PropTypes.string.isRequired,
			specialties: _react.PropTypes.array.isRequired
		}).isRequired
	},
	render: function render() {
		return _react2["default"].createElement(
			"div",
			{ className: "doctor-bio" },
			_react2["default"].createElement(
				"div",
				{ className: "doctor-bio__image" },
				_react2["default"].createElement(
					"a",
					{ href: "#" },
					_react2["default"].createElement("img", { src: this.props.data.picture, alt: this.props.data.name })
				),
				_react2["default"].createElement(
					"span",
					{ className: "doctor-bio__more", onClick: this.props.more.func },
					this.props.more.label
				)
			),
			_react2["default"].createElement(
				"div",
				{ className: "doctor-bio__info" },
				_react2["default"].createElement(
					"h2",
					{ className: "doctor-bio__title" },
					_react2["default"].createElement(
						"a",
						{ href: this.props.data.link },
						this.props.data.name
					)
				),
				_react2["default"].createElement(
					"ul",
					{ className: "doctor-bio__specialties" },
					this.props.data.specialties.map(function (specialty, index) {
						return _react2["default"].createElement(
							"li",
							{ key: index },
							_react2["default"].createElement(
								"a",
								{ href: specialty.link },
								specialty.label
							)
						);
					})
				),
				_react2["default"].createElement(
					"ul",
					{ className: "doctor-bio__rating" },
					_react2["default"].createElement(
						"li",
						null,
						_react2["default"].createElement("i", { className: "fa fa-star" })
					),
					_react2["default"].createElement(
						"li",
						null,
						_react2["default"].createElement("i", { className: "fa fa-star" })
					),
					_react2["default"].createElement(
						"li",
						null,
						_react2["default"].createElement("i", { className: "fa fa-star" })
					),
					_react2["default"].createElement(
						"li",
						null,
						_react2["default"].createElement("i", { className: "fa fa-star" })
					),
					_react2["default"].createElement(
						"li",
						{ className: "empty" },
						_react2["default"].createElement("i", { className: "fa fa-star" })
					)
				)
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],6:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _ResultItemsJsx = require("./ResultItems.jsx");

var _ResultItemsJsx2 = _interopRequireDefault(_ResultItemsJsx);

var _PagerJsx = require("./Pager.jsx");

var _PagerJsx2 = _interopRequireDefault(_PagerJsx);

var _jquery = (typeof window !== "undefined" ? window['jQuery'] : typeof global !== "undefined" ? global['jQuery'] : null);

var _jquery2 = _interopRequireDefault(_jquery);

// list of Results
exports["default"] = _react2["default"].createClass({
	displayName: "DoctorSearch",
	propTypes: {
		perPage: _react.PropTypes.number.isRequired,
		comparePage: _react.PropTypes.string.isRequired
	},

	getInitialState: function getInitialState() {
		return {
			data: [],
			firstResultNum: 1,
			totalResults: 0
		};
	},
	fetchResults: function fetchResults() {
		var _this = this;

		var start = this.state.firstResultNum,
		    end = start + this.props.perPage - 1;

		_jquery2["default"].ajax({
			url: "/api/search/doctors/get",
			cache: false,
			data: { start: start, end: end }
		}).done(function (jsonData, textStatus, jqXHR) {
			_this.setState({
				data: jsonData.results,
				totalResults: jsonData.totalResults
			});
		}).fail(function (jqXHR, textStatus, errorThrown) {
			console.error("Error loading json", jqXHR);
		});
	},
	pageChange: function pageChange(start) {
		// update start number without triggering a render
		this.state.firstResultNum = start;
		// fetch new results
		this.fetchResults();
	},
	componentWillMount: function componentWillMount() {
		this.fetchResults();
	},
	render: function render() {
		return _react2["default"].createElement(
			"section",
			null,
			_react2["default"].createElement(_PagerJsx2["default"], {
				perPage: this.props.perPage,
				firstResultNum: this.state.firstResultNum,
				totalResults: this.state.totalResults,
				pageChange: this.pageChange }),
			_react2["default"].createElement(_ResultItemsJsx2["default"], {
				labels: this.props.labels,
				data: this.state.data,
				comparePage: this.props.comparePage }),
			_react2["default"].createElement(_PagerJsx2["default"], {
				perPage: this.props.perPage,
				firstResultNum: this.state.firstResultNum,
				totalResults: this.state.totalResults,
				pageChange: this.pageChange })
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./Pager.jsx":8,"./ResultItems.jsx":12}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var resultsLoc = document.querySelector('.js-doctor-search');
// if the location doesn't exist
if (null !== resultsLoc) {

	var labels = {
		appointmentButton: "Make An Appointment",
		appointmentCall: "or call",
		appointmentFull: "Not accepting new patients"
	};

	if (resultsLoc.getAttribute('data-add-label')) {
		labels.addLabel = resultsLoc.getAttribute('data-add-label');
	}
	if (resultsLoc.getAttribute('data-remove-label')) {
		labels.removeLabel = resultsLoc.getAttribute('data-remove-label');
	}
	if (resultsLoc.getAttribute('data-office-label')) {
		labels.officeLabel = resultsLoc.getAttribute('data-office-label');
	}
	if (resultsLoc.getAttribute('data-compare-label')) {
		labels.compareLabel = resultsLoc.getAttribute('data-compare-label');
	}
	if (resultsLoc.getAttribute('data-appointment-button')) {
		labels.appointmentButton = resultsLoc.getAttribute('data-appointment-button');
	}
	if (resultsLoc.getAttribute('data-appointmnet-call')) {
		labels.appointmentCall = resultsLoc.getAttribute('data-appointmnet-call');
	}
	if (resultsLoc.getAttribute('data-appointment-full')) {
		labels.appointmentFull = resultsLoc.getAttribute('data-appointment-full');
	}
	if (resultsLoc.getAttribute('data-more-label')) {
		labels.moreInfoLabel = resultsLoc.getAttribute('data-more-label');
	}
	if (resultsLoc.getAttribute('data-less-label')) {
		labels.lessInfoLabel = resultsLoc.getAttribute('data-less-label');
	}
	if (resultsLoc.getAttribute('data-pager-label')) {
		labels.pagerLabel = resultsLoc.getAttribute('data-pager-label');
	}
}

exports["default"] = labels;
module.exports = exports["default"];

},{}],8:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _LabelsJs = require("./Labels.js");

var _LabelsJs2 = _interopRequireDefault(_LabelsJs);

exports["default"] = _react2["default"].createClass({
	displayName: "Pager",
	propTypes: {
		perPage: _react.PropTypes.number.isRequired,
		firstResultNum: _react.PropTypes.number.isRequired,
		totalResults: _react.PropTypes.number.isRequired,
		pageChange: _react.PropTypes.func.isRequired
	},

	getInitialState: function getInitialState() {
		return {
			labels: {
				label1: "Showing",
				label2: "of",
				label3: "results"
			},
			totalPages: 1,
			currentPage: 0
		};
	},
	componentWillMount: function componentWillMount() {
		var newLabels = {},
		    temp = _LabelsJs2["default"].pagerLabel;

		// if a label isn't received
		if (typeof temp === 'undefined' || temp.length === 0) {
			// do nothing
			return;
		}
		// separate the labels from the value place holders
		temp = temp.split('{value}');
		// update the labels
		newLabels.label1 = temp[0];
		newLabels.label2 = temp[1];
		newLabels.label3 = temp[2];

		this.setState({ labels: newLabels });

		this.componentWillReceiveProps(this.props);
	},
	componentWillReceiveProps: function componentWillReceiveProps(nextProps) {
		var totalPages = Math.ceil(nextProps.totalResults / nextProps.perPage),
		    currentPage = (nextProps.firstResultNum - 1) / nextProps.perPage;

		this.setState({ totalPages: totalPages, currentPage: currentPage });
	},
	handlePageClick: function handlePageClick(value, event) {
		event.preventDefault();
		this.props.pageChange(value * this.props.perPage + 1);
	},

	render: function render() {
		var _state$labels = this.state.labels;
		var label1 = _state$labels.label1;
		var label2 = _state$labels.label2;
		var label3 = _state$labels.label3;
		var _props = this.props;
		var totalPages = _props.totalPages;
		var firstResultNum = _props.firstResultNum;
		var end = this.props.firstResultNum + this.props.perPage - 1;
		var pageLinks = [];

		if (end > this.props.totalResults) {
			end = this.props.totalResults;
		}

		for (var i = 0; i < this.state.totalPages; i++) {
			if (i === this.state.currentPage) {
				pageLinks.push(_react2["default"].createElement(
					"li",
					{ key: i, className: "current" },
					i + 1
				));
			} else {
				pageLinks.push(_react2["default"].createElement(
					"li",
					{ key: i },
					_react2["default"].createElement(
						"a",
						{ href: "#", onClick: this.handlePageClick.bind(this, i) },
						i + 1
					)
				));
			}
		}

		return _react2["default"].createElement(
			"div",
			{ className: "pager" },
			_react2["default"].createElement(
				"div",
				{ className: "pager__amount" },
				label1,
				" ",
				firstResultNum,
				"-",
				end,
				" ",
				label2,
				" ",
				totalPages,
				" ",
				label3
			),
			_react2["default"].createElement(
				"ul",
				{ className: "pager__pagination" },
				this.state.currentPage > 0 ? _react2["default"].createElement(
					"li",
					null,
					_react2["default"].createElement(
						"a",
						{ href: "#" },
						_react2["default"].createElement(
							"span",
							{ className: "element-invisible" },
							"Prev"
						),
						" ",
						_react2["default"].createElement("i", { className: "fa fa-angle-left" })
					)
				) : null,
				pageLinks,
				this.state.currentPage < this.state.totalPages - 1 ? _react2["default"].createElement(
					"li",
					null,
					_react2["default"].createElement(
						"a",
						{ href: "#" },
						_react2["default"].createElement(
							"span",
							{ className: "element-invisible" },
							"Next"
						),
						" ",
						_react2["default"].createElement("i", { className: "fa fa-angle-right" })
					)
				) : null
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./Labels.js":7}],9:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _sharedCompareButtonJsx = require("../shared/CompareButton.jsx");

var _sharedCompareButtonJsx2 = _interopRequireDefault(_sharedCompareButtonJsx);

var _LabelsJs = require("./Labels.js");

var _LabelsJs2 = _interopRequireDefault(_LabelsJs);

exports["default"] = _react2["default"].createClass({
	displayName: "ResultCompare",
	propTypes: {
		id: _react.PropTypes.string.isRequired,
		comparePage: _react.PropTypes.string.isRequired
	},

	render: function render() {
		return _react2["default"].createElement(
			"div",
			{ className: "results__compare" },
			_react2["default"].createElement(
				"h4",
				{ className: "results__label" },
				_LabelsJs2["default"].compareLabel
			),
			_react2["default"].createElement(_sharedCompareButtonJsx2["default"], { labels: _LabelsJs2["default"], id: this.props.id }),
			_react2["default"].createElement(
				"a",
				{ className: "button button--secondary", href: this.props.comparePage },
				_react2["default"].createElement("i", { className: "fa fa-list-ul" }),
				" View"
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../shared/CompareButton.jsx":16,"./Labels.js":7}],10:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _LabelsJs = require("./Labels.js");

var _LabelsJs2 = _interopRequireDefault(_LabelsJs);

exports["default"] = _react2["default"].createClass({
	displayName: "ResultContact",
	propTypes: {
		phoneNum: _react.PropTypes.string.isRequired,
		buttonColor: _react.PropTypes.bool,
		appointmentLink: _react.PropTypes.string.isRequired
	},

	getDefaultProps: function getDefaultProps() {
		return {
			buttonColor: true
		};
	},

	formatPhone: function formatPhone(phone) {
		// insert a dot four in from the end
		if (phone.length === 10) {
			return [phone.slice(-10, -7), ".", phone.slice(-7, -4), ".", phone.slice(-4)].join('');
		}
		return phone;
	},

	render: function render() {
		if (this.props.phoneNum === "") {
			return _react2["default"].createElement(
				"div",
				{ className: "results__contact inactive" },
				_react2["default"].createElement(
					"span",
					{ className: "inactive__text" },
					_LabelsJs2["default"].appointmentFull
				)
			);
		} else {
			var phoneNum = this.formatPhone(this.props.phoneNum),
			    phoneLink = "tel:+" + this.props.phoneNum;
			return _react2["default"].createElement(
				"div",
				{ className: "results__contact" },
				_react2["default"].createElement(
					"a",
					{ className: this.props.buttonColor ? 'button' : 'button button--white', href: this.props.appointmentLink },
					_LabelsJs2["default"].appointmentButton
				),
				_react2["default"].createElement(
					"span",
					{ className: "tel" },
					_LabelsJs2["default"].appointmentCall,
					" ",
					_react2["default"].createElement(
						"a",
						{ href: phoneLink },
						phoneNum
					)
				)
			);
		}
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./Labels.js":7}],11:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _DoctorBioJsx = require("./DoctorBio.jsx");

var _DoctorBioJsx2 = _interopRequireDefault(_DoctorBioJsx);

var _ResultContactJsx = require("./ResultContact.jsx");

var _ResultContactJsx2 = _interopRequireDefault(_ResultContactJsx);

var _ResultLocationJsx = require("./ResultLocation.jsx");

var _ResultLocationJsx2 = _interopRequireDefault(_ResultLocationJsx);

var _ResultCompareJsx = require("./ResultCompare.jsx");

var _ResultCompareJsx2 = _interopRequireDefault(_ResultCompareJsx);

var _LabelsJs = require("./Labels.js");

var _LabelsJs2 = _interopRequireDefault(_LabelsJs);

// list of Results
exports["default"] = _react2["default"].createClass({
	displayName: "ResultItem",
	propTypes: {
		data: _react.PropTypes.shape({
			id: _react.PropTypes.string.isRequired,
			profile: _react.PropTypes.object.isRequired,
			locations: _react.PropTypes.array.isRequired,
			phone: _react.PropTypes.string.isRequired,
			appointmentLink: _react.PropTypes.string.isRequired
		}).isRequired,
		comparePage: _react.PropTypes.string.isRequired
	},

	getDefaultProps: function getDefaultProps() {
		return {
			labels: {
				moreInfoLabel: "More Info",
				lessInfoLabel: "Less Info"
			}
		};
	},

	getInitialState: function getInitialState() {
		return {
			expanded: false,
			moreInfoLabel: this.props.labels.moreInfoLabel
		};
	},

	toggleClass: function toggleClass() {
		var label = !this.state.expanded ? _LabelsJs2["default"].lessInfoLabel : _LabelsJs2["default"].moreInfoLabel;

		this.setState({ moreInfoLabel: label, expanded: !this.state.expanded });
	},
	render: function render() {
		var parentClass = "results__item" + (this.state.expanded ? " is-expanded" : "");
		var viewMore = { label: this.state.moreInfoLabel, func: this.toggleClass };

		return _react2["default"].createElement(
			"div",
			{ className: parentClass, "data-id": this.props.data.id },
			_react2["default"].createElement(
				"div",
				{ className: "results__bio" },
				_react2["default"].createElement(_DoctorBioJsx2["default"], { more: viewMore, data: this.props.data.profile })
			),
			_react2["default"].createElement(
				"div",
				{ className: "results__content" },
				_react2["default"].createElement(_ResultLocationJsx2["default"], { data: this.props.data.locations, labels: _LabelsJs2["default"] }),
				_react2["default"].createElement(_ResultCompareJsx2["default"], { id: this.props.data.id, labels: _LabelsJs2["default"], comparePage: this.props.comparePage }),
				_react2["default"].createElement(_ResultContactJsx2["default"], { phoneNum: this.props.data.phone, appointmentLink: this.props.data.appointmentLink })
			),
			_react2["default"].createElement(_ResultContactJsx2["default"], { buttonColor: false, phoneNum: this.props.data.phone, appointmentLink: this.props.data.appointmentLink })
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./DoctorBio.jsx":5,"./Labels.js":7,"./ResultCompare.jsx":9,"./ResultContact.jsx":10,"./ResultLocation.jsx":13}],12:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _ResultItemJsx = require("./ResultItem.jsx");

var _ResultItemJsx2 = _interopRequireDefault(_ResultItemJsx);

// list of Results
exports["default"] = _react2["default"].createClass({
	displayName: "ResultList",
	propTypes: {
		data: _react.PropTypes.array.isRequired,
		comparePage: _react.PropTypes.string.isRequired
	},

	render: function render() {
		var _this = this;

		return _react2["default"].createElement(
			"div",
			{ className: "results" },
			this.props.data.map(function (result, index) {
				return _react2["default"].createElement(_ResultItemJsx2["default"], { key: index, data: result, comparePage: _this.props.comparePage });
			})
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./ResultItem.jsx":11}],13:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

exports["default"] = _react2["default"].createClass({
	displayName: "ResultLocation",
	propTypes: {
		data: _react.PropTypes.array.isRequired
	},
	getDefaultProps: function getDefaultProps() {
		return {
			labels: {
				officeLabel: "Office Locations"
			}
		};
	},
	render: function render() {
		return _react2["default"].createElement(
			"div",
			{ className: "results__locations" },
			_react2["default"].createElement(
				"h4",
				{ className: "results__label" },
				this.props.labels.officeLabel
			),
			_react2["default"].createElement(
				"ul",
				{ className: "results__locations__list" },
				this.props.data.map(function (location, index) {
					return _react2["default"].createElement(
						"li",
						{ key: index },
						_react2["default"].createElement(
							"a",
							{ href: location.link },
							location.label
						)
					);
				})
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],14:[function(require,module,exports){
(function (global){
"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _reactDom = (typeof window !== "undefined" ? window['ReactDOM'] : typeof global !== "undefined" ? global['ReactDOM'] : null);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _DoctorSearchJsx = require("./DoctorSearch.jsx");

var _DoctorSearchJsx2 = _interopRequireDefault(_DoctorSearchJsx);

// Parent controller for the doctor search app
;(function () {
	// find the location for the code
	var resultsLoc = document.querySelector('.js-doctor-search'),
	    perPage = 10,
	    comparePage = "";
	// if the location doesn't exist
	if (null === resultsLoc) {
		return;
	}

	if (resultsLoc.getAttribute('data-per-page')) {
		perPage = parseInt(resultsLoc.getAttribute('data-per-page'));
	}
	if (resultsLoc.getAttribute('data-compare-page')) {
		comparePage = resultsLoc.getAttribute('data-compare-page');
	}

	_reactDom2["default"].render(_react2["default"].createElement(_DoctorSearchJsx2["default"], { perPage: perPage, comparePage: comparePage }), resultsLoc);
})();

//export { object };

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./DoctorSearch.jsx":6}],15:[function(require,module,exports){
"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _commonCommonJs = require("./common/common.js");

var _commonCommonJs2 = _interopRequireDefault(_commonCommonJs);

var _doctorSearchIndexJs = require("./doctor-search/index.js");

var _doctorSearchIndexJs2 = _interopRequireDefault(_doctorSearchIndexJs);

var _sharedCompareButtonJs = require("./shared/compareButton.js");

var _sharedCompareButtonJs2 = _interopRequireDefault(_sharedCompareButtonJs);

var _taskNavigationIndexJs = require("./task-navigation/index.js");

var _taskNavigationIndexJs2 = _interopRequireDefault(_taskNavigationIndexJs);

var _commonLibJs = require("./common/lib.js");

var _commonLibJs2 = _interopRequireDefault(_commonLibJs);

var _commonGoogleMapJs = require("./common/googleMap.js");

var _commonGoogleMapJs2 = _interopRequireDefault(_commonGoogleMapJs);

jQuery.noConflict();
// flag the page as loaded - assuming file included at bottom of page
jQuery('html').addClass('is-dom-ready');

_commonCommonJs2["default"].init();

_commonGoogleMapJs2["default"].init();

},{"./common/common.js":1,"./common/googleMap.js":2,"./common/lib.js":3,"./doctor-search/index.js":14,"./shared/compareButton.js":17,"./task-navigation/index.js":20}],16:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

// import Cookie 				from 'react-cookie';

exports["default"] = _react2["default"].createClass({
	displayName: "CompareButton",
	cookieName: "doctorCompare",

	propTypes: {
		id: _react.PropTypes.string.isRequired,
		labels: _react.PropTypes.object
	},

	getDefaultProps: function getDefaultProps() {
		return {
			labels: {
				addLabel: "Add",
				removeLabel: "Remove"
			}
		};
	},

	getInitialState: function getInitialState() {
		return {
			isAdded: false
		};
	},
	componentWillMount: function componentWillMount() {
		var _this = this;

		// find the compare doctor cookie data
		var data = Cookies.get(this.cookieName) || "";
		// if compare doctor cookie not found
		if (typeof data === 'undefined') {
			// do nothing
			return;
		}
		// split the cookie data
		data = data.split(',');
		// if matching id found in cookie
		if (data.some(function (elem) {
			return elem === _this.props.id;
		})) {
			// set state as added
			this.setState({ isAdded: true });
		}
	},
	toggleButton: function toggleButton(event) {
		var _this2 = this;

		event.preventDefault();
		var data = Cookies.get(this.cookieName).split(',') || [];
		// if current state is added
		if (this.state.isAdded) {
			// remove the id from the cookie
			data = data.filter(function (value) {
				return value !== _this2.props.id;
			});
		} else {
			// otherwise
			// add the id to the cookie data
			data.push(this.props.id);
		}
		// add the cookie data to the cookie
		Cookies.set(this.cookieName, data.join(','), { path: '/' });
		// toggle the current state and upset the state.
		this.setState({ isAdded: !this.state.isAdded });
	},
	render: function render() {
		var addRemoveElement = _react2["default"].createElement("i", { className: "fa fa-plus" }),
		    addRemoveLabel = this.props.labels.addLabel;

		if (this.state.isAdded) {
			addRemoveElement = _react2["default"].createElement("i", { className: "fa fa-minus" });
			addRemoveLabel = this.props.labels.removeLabel;
		}
		return _react2["default"].createElement(
			"a",
			{ className: "button button--secondary", href: "#", onClick: this.toggleButton },
			addRemoveElement,
			" ",
			addRemoveLabel
		);
	}

});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],17:[function(require,module,exports){
(function (global){
"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _reactDom = (typeof window !== "undefined" ? window['ReactDOM'] : typeof global !== "undefined" ? global['ReactDOM'] : null);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _CompareButtonJsx = require("./CompareButton.jsx");

var _CompareButtonJsx2 = _interopRequireDefault(_CompareButtonJsx);

// Parent controller for the doctor search app
;(function () {
	// find the location for the code
	var buttonLoc = document.querySelector('.js-compare-button'),
	    labels = {},
	    id = "";

	// if the location doesn't exist
	if (null === buttonLoc) {
		return;
	}

	labels = {
		addLabel: buttonLoc.getAttribute('data-add-label'),
		removeLabel: buttonLoc.getAttribute('data-remove-label')
	};
	id = buttonLoc.getAttribute('data-id');

	_reactDom2["default"].render(_react2["default"].createElement(_CompareButtonJsx2["default"], { labels: labels, id: id }), buttonLoc);
})();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./CompareButton.jsx":16}],18:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _jquery = (typeof window !== "undefined" ? window['jQuery'] : typeof global !== "undefined" ? global['jQuery'] : null);

var _jquery2 = _interopRequireDefault(_jquery);

exports["default"] = _react2["default"].createClass({
	displayName: "DropDown",

	propTypes: {
		handleChange: _react.PropTypes.func.isRequired,
		activeLink: _react.PropTypes.string.isRequired,
		links: _react.PropTypes.array.isRequired
	},

	// when the user picks a new value
	handleMenuChange: function handleMenuChange(value, event) {
		// prevent the default action
		event.preventDefault();
		// pass the new value back to the parent
		this.props.handleChange(value);
	},

	render: function render() {
		var _this = this;

		if (this.props.links.length === 1 && this.props.links[0] === "") {
			return _react2["default"].createElement(
				"span",
				null,
				"--"
			);
		}

		return _react2["default"].createElement(
			"ul",
			{ className: "splash__nav__select", ref: function (ref) {
					(0, _jquery2["default"])(ref).dropit();
				} },
			_react2["default"].createElement(
				"li",
				{ className: "selected-item" },
				_react2["default"].createElement(
					"a",
					{ href: "javascript:void(0);" },
					this.props.activeLink
				),
				_react2["default"].createElement(
					"ul",
					{ className: "splash__nav__menu" },
					this.props.links.map(function (link, index) {
						return _react2["default"].createElement(
							"li",
							{ key: index },
							_react2["default"].createElement(
								"a",
								{ href: "#", onClick: _this.handleMenuChange.bind(_this, index) },
								link
							)
						);
					})
				)
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],19:[function(require,module,exports){
(function (global){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _DropDownJsx = require("./DropDown.jsx");

var _DropDownJsx2 = _interopRequireDefault(_DropDownJsx);

exports["default"] = _react2["default"].createClass({
	displayName: "TaskNavigation",

	propTypes: {
		id: _react.PropTypes.string.isRequired,
		button: _react.PropTypes.string,
		messageA: _react.PropTypes.string,
		messageB: _react.PropTypes.string,
		updateBackground: _react.PropTypes.func.isRequired
	},

	getDefaultProps: function getDefaultProps() {
		return {
			button: "Continue"
		};
	},

	getInitialState: function getInitialState() {
		return {
			currentPersona: 0,
			currentTask: 0,
			data: {},
			currentTasks: [""],
			personaValues: [""],
			buttonLink: "#"
		};
	},

	componentWillMount: function componentWillMount() {
		var _this = this;

		var self = this;
		// get the GUID
		var guid = this.props.id;
		// fetch the API data
		fetch('/api/taskNav/get/{' + guid + '}').then(function (response) {
			return response.json();
		}).then(function (response) {
			// if we send a bad request
			if (response.message) {
				console.log(response);
				// exit
				return;
			}
			var data = response.personas;
			// create an Array with just the Persona labels
			var personas = data.map(function (persona) {
				return persona.name;
			});
			// record the first list of tasks
			var tasks = data[0].taskItems.map(function (task) {
				return task.name;
			});
			// record the button link for the first task
			var buttonLink = data[0].taskItems[0].link.link;
			// update the model
			_this.setState({
				data: data,
				personaValues: personas,
				currentTasks: tasks,
				buttonLink: buttonLink
			});

			return data;
		})["catch"](function (ex) {
			console.log('parsing failed', ex);
		});
	},

	handlePersona: function handlePersona(index) {
		// if the new persona matches the existing
		if (this.state.currentPersona === index) {
			// do nothing
			return;
		}
		// change the parent's background image
		this.props.updateBackground(this.state.data[index].bannerImageUrl);
		// create the new list of tasks
		var tasks = this.state.data[index].taskItems.map(function (task) {
			return task.name;
		});
		// get the new button link
		var buttonLink = this.state.data[index].taskItems[0].link.link;
		// update the model with the new state
		this.setState({ currentPersona: index, currentTask: 0, currentTasks: tasks, buttonLink: buttonLink });
	},

	handleTask: function handleTask(index) {
		// if the new persona matches the existing
		if (this.state.currentTask === index) {
			// do nothing
			return;
		}
		// get the new button link
		var buttonLink = this.state.data[this.state.currentPersona].taskItems[index].link.link;
		// update the model with the new state
		this.setState({ currentTask: index, buttonLink: buttonLink });
	},

	render: function render() {

		return _react2["default"].createElement(
			"div",
			{ className: "splash__nav" },
			_react2["default"].createElement(
				"span",
				{ className: "splash__nav__text" },
				this.props.messageA,
				" "
			),
			_react2["default"].createElement(_DropDownJsx2["default"], {
				handleChange: this.handlePersona,
				activeLink: this.state.personaValues[this.state.currentPersona],
				links: this.state.personaValues }),
			_react2["default"].createElement(
				"span",
				{ className: "splash__nav__text" },
				" ",
				this.props.messageB,
				" "
			),
			_react2["default"].createElement(_DropDownJsx2["default"], {
				handleChange: this.handleTask,
				activeLink: this.state.currentTasks[this.state.currentTask],
				links: this.state.currentTasks }),
			" ",
			_react2["default"].createElement(
				"a",
				{ className: "button", href: this.state.buttonLink },
				_react2["default"].createElement(
					"span",
					{ className: "splash_continue" },
					this.props.button
				),
				" ",
				_react2["default"].createElement("i", { className: "fa fa-chevron-right" })
			)
		);
	}
});
module.exports = exports["default"];

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./DropDown.jsx":18}],20:[function(require,module,exports){
(function (global){
"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);

var _react2 = _interopRequireDefault(_react);

var _reactDom = (typeof window !== "undefined" ? window['ReactDOM'] : typeof global !== "undefined" ? global['ReactDOM'] : null);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _TaskNavigationJsx = require("./TaskNavigation.jsx");

var _TaskNavigationJsx2 = _interopRequireDefault(_TaskNavigationJsx);

// Parent controller for the doctor search app
;(function () {
	// find the location for the code
	var taskNavLocation = document.querySelector('.js-task-navigation'),
	    button = "",
	    id = "",
	    messageA = "",
	    messageB = "";

	// if the location doesn't exist
	if (null === taskNavLocation) {
		return;
	}

	button = taskNavLocation.getAttribute('data-button-label');
	id = taskNavLocation.getAttribute('data-guid');
	messageA = taskNavLocation.getAttribute('data-message-a');
	messageB = taskNavLocation.getAttribute('data-message-b');

	function updateBackground(image) {
		// find the current background element
		var current = document.querySelector('.js-task-navigation-background');
		// find the parent node
		var parent = current.parentNode;
		// copy the current background element
		var copy = document.createElement('div');
		// add the classes
		copy.className = current.className;
		// add the new background image to the copy
		copy.style.backgroundImage = "url(" + image + ")";
		// insert the copy before the current element
		parent.insertBefore(copy, current);
		// wait for the transition to complete
		setTimeout(function () {
			// remove the current element
			parent.removeChild(current);
		}, 1000);
	}

	_reactDom2["default"].render(_react2["default"].createElement(_TaskNavigationJsx2["default"], {
		button: button,
		id: id,
		messageA: messageA,
		messageB: messageB,
		updateBackground: updateBackground }), taskNavLocation);
})();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./TaskNavigation.jsx":19}]},{},[15])


//# sourceMappingURL=index.js.map
