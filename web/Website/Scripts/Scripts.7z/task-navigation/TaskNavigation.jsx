import React, {PropTypes}	from "react";
import DropDown 			from "./DropDown.jsx";

export default React.createClass({
	displayName: "TaskNavigation",

	propTypes: {
		id: PropTypes.string.isRequired,
		button: PropTypes.string,
		messageA: PropTypes.string,
		messageB: PropTypes.string,
		updateBackground: PropTypes.func.isRequired
	},

	getDefaultProps: function() {
		return {
			button: "Continue"
		};
	},

	getInitialState: function() {
		return {
			currentPersona: 0,
			currentTask: 0,
			data: {},
			currentTasks: [""],
			personaValues: [""],
			buttonLink: "#"
		};
	},

	componentWillMount: function(){
		let self = this;
		// get the GUID
		let guid = this.props.id;
		// fetch the API data
		fetch('/api/taskNav/get/{' + guid + '}')
			.then((response) => response.json())
			.then((response) => { 
				// if we send a bad request
				if(response.message){
					console.log(response);
					// exit
					return;
				}
				let data = response.personas;
				// create an Array with just the Persona labels
				let personas = data.map((persona) => persona.name);
				// record the first list of tasks
				let tasks = data[0].taskItems.map((task) => task.name);
				// record the button link for the first task
				let buttonLink = data[0].taskItems[0].link.link;
				// update the model
				this.setState({
					data: data,
					personaValues: personas,
					currentTasks: tasks,
					buttonLink: buttonLink
				})

				return data; 
			})
			.catch((ex) => { console.log('parsing failed', ex) });
	},

	handlePersona: function(index){
		// if the new persona matches the existing
		if(this.state.currentPersona === index){
			// do nothing
			return;
		}
		// change the parent's background image
		this.props.updateBackground(this.state.data[index].bannerImageUrl)
		// create the new list of tasks
		let tasks = this.state.data[index].taskItems.map((task) => task.name);
		// get the new button link
		let buttonLink = this.state.data[index].taskItems[0].link.link;
		// update the model with the new state
		this.setState({currentPersona:index, currentTask:0, currentTasks:tasks, buttonLink:buttonLink});
	},

	handleTask: function(index){
		// if the new persona matches the existing
		if(this.state.currentTask === index){
			// do nothing
			return;
		}
		// get the new button link
		let buttonLink = this.state.data[this.state.currentPersona].taskItems[index].link.link;
		// update the model with the new state
		this.setState({currentTask:index, buttonLink:buttonLink});
	},

	render: function() {

		return (
			<div className="splash__nav">
				<span className="splash__nav__text">{this.props.messageA}&nbsp;</span>
				<DropDown
					handleChange = {this.handlePersona}
					activeLink = {this.state.personaValues[this.state.currentPersona]}
					links = {this.state.personaValues} />
				<span className="splash__nav__text">&nbsp;{this.props.messageB}&nbsp;</span>
				<DropDown 
					handleChange = {this.handleTask}
					activeLink = {this.state.currentTasks[this.state.currentTask]}
					links = {this.state.currentTasks} />
				&nbsp;
				<a className="button" href={this.state.buttonLink}><span className="splash_continue">{this.props.button}</span> <i className="fa fa-chevron-right"></i></a>
			</div>
		);
	}
});