import React      		from "react";
import ReactDOM   		from "react-dom";
import CompareButton 	from "./CompareButton.jsx";

// Parent controller for the doctor search app
;(function(){
	// find the location for the code
	var buttonLoc = document.querySelector('.js-compare-button'),
		labels = {},
		id = "";

	// if the location doesn't exist
	if (null === buttonLoc){
		return;
	}

	labels = {
		addLabel: buttonLoc.getAttribute('data-add-label'),
		removeLabel: buttonLoc.getAttribute('data-remove-label')
	};
	id = buttonLoc.getAttribute('data-id');

	ReactDOM.render(
		<CompareButton labels={labels} id={id} />,
		buttonLoc
	);

})();