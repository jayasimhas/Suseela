import React, {PropTypes}	from "react";
// import Cookie 				from 'react-cookie';

export default React.createClass({
	displayName: "CompareButton",
	cookieName: "doctorCompare",

	propTypes: {
		id: PropTypes.string.isRequired,
		labels: PropTypes.object
	},

	getDefaultProps: function() {
		return {
			labels: {
				addLabel: "Add",
				removeLabel: "Remove"
			}
		};
	},

	getInitialState: function() {
		return {
			isAdded: false
		};
	},
	componentWillMount: function(){
		// find the compare doctor cookie data
		var data = Cookies.get(this.cookieName) || "";
		// if compare doctor cookie not found
		if(typeof(data) === 'undefined'){
			// do nothing
			return;
		}
		// split the cookie data
		data = data.split(',');		
		// if matching id found in cookie
		if(data.some(elem => elem === this.props.id)){
			// set state as added
			this.setState({isAdded:true});
		}
	},
	toggleButton: function(event) {
		event.preventDefault();
		var data = Cookies.get(this.cookieName).split(',') || [];
		// if current state is added
		if(this.state.isAdded){
			// remove the id from the cookie
			data = data.filter(value => value !== this.props.id);
		} else {
			// otherwise
			// add the id to the cookie data
			data.push(this.props.id);
		}
		// add the cookie data to the cookie
		Cookies.set(this.cookieName, data.join(','),{path:'/'});
		// toggle the current state and upset the state.
		this.setState({isAdded:!this.state.isAdded})
	},
	render: function() {
		var addRemoveElement = <i className="fa fa-plus"></i>,
			addRemoveLabel = this.props.labels.addLabel;

		if(this.state.isAdded){
			addRemoveElement = <i className="fa fa-minus"></i>;
			addRemoveLabel = this.props.labels.removeLabel;
		}
		return(
			<a className="button button--secondary" href="#" onClick={this.toggleButton} >
				{addRemoveElement} {addRemoveLabel}
			</a>
		);
	}


});