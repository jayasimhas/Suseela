import $ 				from "jquery";
import removeCookie 	from "./removeCookie.js";

"use strict";

// Compare Doctors - remove doctor from list
function removeCompareDoctor() {
	// when a remove doctor button is clicked
	$('.js-remove-doctor').on('click',function(event){
		event.preventDefault();
		let $el = $(this),  // record the current element
			id = $el.data('doctor-id'), // get the ID of the doctor
			$parents = $('.js-doctor-object[data-doctor-id="'+ id + '"]'); // find the parent rows

		// remove the row
		$parents.fadeOut('slow');
		// remove the doctor's id from the cookie
		removeCookie('doctorCompare',id);
	});
}

// calculate the distance from our location to a specified lat and lngg coordinate
function distancefromHere() {
	$('.js-distance-from-here').each(function(){
		let lat = $(this).data('lat'),
			lng = $(this).data('lng'),
			distance,
			$el = $(this);

		// if lat and lng are not found
		if(typeof(lat) === "undefined" || lat.length === 0 || typeof(lng) === "undefined" || lng.length === 0){
			// do nothing
			return;
		}

		getDistance(lat,lng)
			.then(function(distance){
				$el.text(parseInt(distance) + " miles");
			})
			.catch(function(err){
				console.log(err.message);
			});
	});
}
// Google webfont loader
function loadFonts() {
	var wf = document.createElement('script'), 
		scripts = document.scripts[0];

	// Set the fonts to load
	window.WebFontConfig = {
		google: {
			families: [
				'Montserrat:400,700:latin',
				'Roboto:400,400italic,700,700italic,300italic,300:latin',
				'Arvo::latin'
			]
		}
	};
	// Add the Google Fonts JS file
	wf.src = '//ajax.googleapis.com/ajax/libs/webfont/1.5.18/webfont.js';
	scripts.parentNode.insertBefore(wf, scripts);
}
// jQuery DotDotDot truncation
function truncate(){
	// for every truncated item on the page
	$('.js-truncate').each(function(){
		var $el = $(this);
		// apply the truncated class to the element
		$el.parent().addClass('is-truncated');
		// apply dotdotdot to the element
		$el.dotdotdot({
			watch:true,
			callback: function(isTruncated,orgContent){
				if(isTruncated){
					$el.parent().find('.js-untruncate').show();
				} else {
					$el.parent().find('.js-untruncate').hide();
				}

			}
		});
		// bind a click event to undo this
		$el.parent().on('click','.js-untruncate', function(){
			$el.parent().removeClass('is-truncated');
			$el.trigger("destroy");
			// remove this link from the content
			$(this).remove();
		});
	});
}

function newsletterForm() {
	let emailRegx = /.+?@.+?[.].+/;

	// for each newsletter form on the page
	$('.js-newsletter-form').each(function(){
		let $el = $(this),
			$input = $(this).find('input'),
			$button = $(this).find('button'),
			id = $el.data('id'),
			successMessage = $el.data('success'),
			timer;

		// When the user starts typing 
		$input.on('keyup', function() {
			// record what the user has entered
			let value = $(this).val();
			// prevent previous data validation
			window.clearTimeout(timer);
			// if the field is empty
			if(value.length === 0){
				// reset the flags and exit
				$el.removeClass('is-valid is-invalid');
				return;
			}
			// when the user pauses typing
			timer = setTimeout(() => {
				// validation the entered value
				test(value);
			},600);
		});
		// When the user submits the form
		$button.on('click', function() {
			// record what the user has entered
			let	value = $input.val();
			// prevent previous data validation
			window.clearTimeout(timer);
			// if the user hasn't entered an email
			if(!test(value)){
				// do nothing
				return;
			}
			// prevent the user from submitting another email
			$(this).prop("disabled",true);
			$input.prop("disabled",true);
			// reset the flags
			$el.removeClass('is-valid is-invalid');
			// send the value to the api
			fetch('/api/mailchimp/post/' + id + '/' + value,{method:'POST'})
				.then((response) => {
					// if the request was successful
					if(response.statusText === "OK"){
						// show the success flag
						$el.addClass('is-valid');
						// display the success message and slowly fade it out
						$input
							.val(successMessage)
							.css({'transition':'color 10s','color':'#444'});
						// After the message has faded 
						setTimeout(() => {
							// reset the input value
							value = "";
							$input.val(value).removeAttr('style').prop("disabled",false);
							// reactivate the button
							$(this).prop("disabled",false);
							// reset the flags
							$el.removeClass('is-valid is-invalid');
						},10000);
					} else {
						// show the failed flag
						$el.addClass('is-invalid');
						// reactivate the button
						$(this).prop("disabled",false);
					}
				})
				.catch((e) => { console.log('fetch failed', e) });
		});

		function test(value){
			// if the user has entered an email
			if(emailRegx.test(value)){
				// show the success flag
				$el.removeClass('is-invalid').addClass('is-valid');
				return true;
			}
			// otherwise show the failed flag
			$el.removeClass('is-valid').addClass('is-invalid');
			return false;
		}
	});

}

/* *********** PUBLIC Functions ************************* */

// return the distance in miles from the current location to the desired location
function getDistance(lat1, lng1){
	return new Promise(function(resolve, reject) {
		var dist = 0;

		if (navigator.geolocation) {
			// appears to be async.
			navigator.geolocation.getCurrentPosition(
				function success(position){
					//http://www.geodatasource.com/developers/javascript
					let lat2 = position.coords.latitude,
						lng2 = position.coords.longitude,
						radlat1 = Math.PI * lat1/180,
						radlat2 = Math.PI * lat2/180,
						radlng1 = Math.PI * lng1/180,
						radlng2 = Math.PI * lng2/180,
						theta = lng1-lng2,
						radtheta = Math.PI * theta/180;

					dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
					dist = Math.acos(dist);
					dist = dist * 180/Math.PI;
					dist = dist * 60 * 1.1515;
					resolve(dist);
				},
				function error(error){
					reject(new Error("location data incorrect"));
				}
			);
		} else {
			reject(new Error("Geolocation not supported"));
		}
	});	
}


function init() {
	// get the google webFonts
	loadFonts();
	truncate();
	distancefromHere();
	removeCompareDoctor();
	newsletterForm();
}

export default { 
		init: init,
		getDistance: getDistance
}

