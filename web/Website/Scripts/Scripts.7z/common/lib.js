/**
 * @file
 * @preserve A JavaScript file to append classes based on viewport scroll.
 *
 * @copyright Copyright (c) 2015 Palantir.net
 */

;( function( $ ) {
"use strict";

  $( document ).ready( function() {

    ////////////////////////////////////////////////
    // Trigger Select2
    ////////////////////////////////////////////////

    $( "select.select2" ).select2();
    $( "select.select2-multi" ).select2();

    ////////////////////////////////////////////////
    // Add and remove class for active location
    ////////////////////////////////////////////////

    $( ".list__item--location" ).click( function() {
      $( this ).addClass( "active" );
      $( this ).siblings( ".list__item" ).removeClass( "active" );
    } );

    ////////////////////////////////////////////////
    // Add placeholder text to fields IE9 and below
    ////////////////////////////////////////////////

    $( "input, textarea" ).placeholder();

    ////////////////////////////////////////////////
    // Add wrapping class around tables
    ////////////////////////////////////////////////

    // This should be targeted at RTE tables and not any table on the site. - Jonathan
    // $( ".l-block table" ).wrap( "<div class='table-wrap'></div>" );

    ////////////////////////////////////////////////
    // Toggle more office addresses
    ////////////////////////////////////////////////

    $( ".profile-offices .view-offices" ).click( function() {
      $( this ).toggleClass( "open" );
      $( this ).text( function( i, text ) {
          return text === "View fewer offices " ? "View more offices " : "View fewer offices ";
      } );
      $( this ).siblings( ".profile-offices__all" ).slideToggle();
    } );

    ////////////////////////////////////////////////
    // Add class to odd element in list block full
    ////////////////////////////////////////////////

    $( ".list--block--full .list__item:odd" ).addClass( "odd" );

    ///////////////////////////////////////////
    // Styleguide code view toggle
    ///////////////////////////////////////////

    $( ".view-code > .view-code__link" ).click( function() {
      $( this ).toggleClass( "open" );
      $( this ).siblings( "pre" ).slideToggle( "fast" );
    } );

    ///////////////////////////////////////////
    // Doctor profile tab interface
    ///////////////////////////////////////////

    $( ".toggle-content" ).each( function() {
        var wrapper = $( this );

        var hasTabs = wrapper.hasClass( "tabs" );
        var startOpen = wrapper.hasClass( "open" );

        var dl = wrapper.children( ".tabs-wrap:first" );
        var dts = dl.children( ".tab" );
        var panes = dl.children( ".tab-container" );
        var groups = new Array( dts, panes );

        // Create a ul for tabs if necessary.
        if ( hasTabs ) {
            var ul = $( "<ul class='toggle-tabs'></ul>" );
            dts.each( function() {
                var dt = $( this );
                var li = $( "<li></li>" );
                li.html( dt.html() );
                ul.append( li );
            } );
            ul.insertBefore( dl );
            var lis = ul.children();
            groups.push( lis );
        }

        // Add "last" classes.
        var i;
        for ( i = 0; i < groups.length; i++ ) {
            groups[ i ].filter( ":last" ).addClass( "last" );
        }

        function toggleClasses( clickedItem, group ) {
            var index = group.index( clickedItem );
            var i;
            for ( i = 0; i < groups.length; i++ ) {
                groups[ i ].removeClass( "current" );
                groups[ i ].eq( index ).addClass( "current" );
            }
        }

        // Toggle on tab (.tab) click.
        dts.on( "click", function() {
            toggleClasses( $( this ), dts );
        } );

        // Toggle on tab (li) click.
        if ( hasTabs ) {
            lis.on( "click", function( event ) {
                toggleClasses( $( this ), lis );
                event.preventDefault();
            } );

            // Open the first tab.
            lis.eq( 0 ).trigger( "click" );
        }

        // Open the first accordion if desired.
        if ( startOpen ) {
            dts.eq( 0 ).trigger( "click" );
        }

    } );

    ///////////////////////////////////////////
    // Search results toggle
    ///////////////////////////////////////////

    $( ".content-type__menu-toggle" ).click( function() {
      $( this ).siblings( ".search-content-type" ).slideToggle();
      $( this ).toggleClass( "open" );
    } );

    ///////////////////////////////////////////
    // Location nav
    ///////////////////////////////////////////

    $( ".location--nav__menu-toggle" ).click( function() {
      $( this ).siblings( ".location--nav__parent" ).slideToggle();
    } );

    $( ".location--nav__parent > li" ).hover( function() {
      $( this ).toggleClass( "location--nav-active" );
    } );

    $( ".location--nav__parent .has-children" ).append( "<i class='fa fa-angle-down'></i>" );
    $( ".location--nav__parent .has-children i" ).click( function() {

      // Only trigger if screen size is smaller than 900px
      if ( $( window ).width() < 900 ) {
        $( this ).toggleClass( "opened" );
        $( this ).siblings( ".location--nav__level2" ).slideToggle();
      }
    } );

    function accessibleLocationNav() {
      var el = $( ".location--nav" );

      // Make dropdown menus keyboard accessible
      $( "a", el ).focus( function() {
        $( this ).parents( "li" ).addClass( "location--nav-active" );
      } ).blur( function() {
        $( this ).parents( "li" ).removeClass( "location--nav-active" );
      } );
    }

    // Run keyboard controls for location nav
    accessibleLocationNav();

    ///////////////////////////////////////////
    // Fadeout filter tags
    ///////////////////////////////////////////

    $( ".filter-tag i" ).click( function() {
      $( this ).parent( ".filter-tag" ).fadeOut();
    } );

    ///////////////////////////////////////////
    // Toggle more filters
    ///////////////////////////////////////////

    $( ".button--more-options" ).click( function() {
      $( this ).parent( ".form-view-filters" ).siblings( ".form-more-options" ).slideToggle();
      $( this ).html( function( i, html ) {
          return html === '<i class="fa fa-chevron-down"></i> View Filters' ? '<i class="fa fa-chevron-up"></i> Hide Filters' : '<i class="fa fa-chevron-down"></i> View Filters';
      } );
    } );

    ///////////////////////////////////////////
    // Trigger FitVids on body tag
    ///////////////////////////////////////////

    $( "body" ).fitVids();

    ///////////////////////////////////////////
    // Toggle doctors results info
    ///////////////////////////////////////////

    $( ".results__item__more-link" ).click( function() {
      $( this ).parent( ".results__item__img" ).siblings( ".results__item__more-info" ).slideToggle();

      // Toggle text in link
      if ( $( this ).text() === "More Info" ) {
        $( this ).text( "Less Info" );
      } else {
        $( this ).text( "More Info" );
      }
    } );

    ///////////////////////////////////////////
    // Set min height for certain elements
    ///////////////////////////////////////////

    $( ".callout, .list--featured-hero .list__item" ).matchHeight( {
      byRow: true,
      property: "min-height",
      remove: false
    } );

    ///////////////////////////////////////////
    // Appointment slideshow
    ///////////////////////////////////////////

    $( ".appointment-form" ).flexslider( {
      animation: "slide",
      manualControls: ".appointment-nav li",
      controlsContainer: ".appointment__buttons",
      prevText: "Previous Step",
      nextText: "Next Step",
      useCSS: false,
      animationLoop: false,
      slideshow:    false,
      smoothHeight: true,
      before: function() {
        $( ".appointment__buttons .flex-nav-submit" ).removeClass( "active" );
      },
      end: function() {
        $( ".appointment__buttons .flex-nav-submit" ).addClass( "active" );
      }
    } );

    // Add markup and classes to appointment nav
    $( ".appointment__buttons .flex-prev" ).prepend( "<i class='fa fa-angle-left'></i> " ).addClass( "button button--secondary button--large" );
    $( ".appointment__buttons .flex-next" ).append( " <i class='fa fa-angle-right'></i>" ).addClass( "button button--large" );
    $( ".appointment__buttons .flex-direction-nav" ).append( "<li class='flex-nav-submit'><a class='button button--large' href='javascript:void(0);'>Submit Appointment</a></li>" );

    ///////////////////////////////////////////
    // Spotlight slideshow
    ///////////////////////////////////////////

    $( ".spotlight" ).flexslider( {
      animation: "slide",
      slideshow: false
    } );

    ///////////////////////////////////////////
    // Sidebar proximity nav toggle
    ///////////////////////////////////////////

    $( ".prox-nav__level2 .has-children > a" ).after( "<i tabindex='0' class='fa fa-angle-down'></i>" );

    $( ".prox-nav__level2 .has-children i" ).focus( function() {
      $( this ).toggleClass( "opened" );
      $( this ).siblings( ".prox-nav__level3" ).slideToggle();
    } );

    $( ".prox-nav__level2 .has-children i" ).click( function() {
      // Remove :focus on i tag when it is clicked
      $( this ).blur();
    } );
    // expand third level tier if active
    $( ".prox-nav__level3 .is-active")
      .closest(".prox-nav__level2")
      .find("i").addClass("opened")
      .siblings(".prox-nav__level3").slideDown();

    ///////////////////////////////////////////
    // Header mega menu toggle
    ///////////////////////////////////////////

    $( ".site-header--nav li a, .site-header--large .button--appointment" ).click( function( event ) {
      var $this = $( this );

      $( ".bg-overlay" ).addClass( "active" );

      if ( $this.data( "clicked", true ).hasClass( "active" ) ) {
        $this.toggleClass( "active" );
        $( ".site-header__dropdowns__item" ).removeClass( "active" );
        $( ".bg-overlay" ).removeClass( "active" );

      } else {

       // Check if the tabs menu has active class
        $( ".site-header--nav li a" ).removeClass( "active" );
        $this.addClass( "active" );

        // Display active tab
        var currentTab = $( this ).attr( "href" );
        $( ".site-header__dropdowns__item" ).removeClass( "active" );
        $( currentTab ).addClass( "active" );
      }
      event.preventDefault();
    } );

    ///////////////////////////////////////////
    // Mobile I"d like to toggle
    ///////////////////////////////////////////

    $( ".button--like-to" ).click( function() {

      if ( $( this ).hasClass( "active" ) ) {
        $( this ).removeClass( "active" );
        $( ".like-to" ).removeClass( "active" );
        $( ".bg-overlay" ).removeClass( "active" );

      } else {
        $( this ).addClass( "active" );
        $( ".like-to" ).addClass( "active" );
        $( ".button--search--small, .search--small" ).removeClass( "active" );
        $( ".bg-overlay" ).addClass( "active" );
      }
    } );

    ///////////////////////////////////////////
    // Mobile search toggle
    ///////////////////////////////////////////

    $( ".button--search--small" ).click( function() {

      if ( $( this ).hasClass( "active" ) ) {
        $( this ).removeClass( "active" );
        $( ".search--small" ).removeClass( "active" );
        $( ".bg-overlay" ).removeClass( "active" );

      } else {
        $( this ).addClass( "active" );
        $( ".search--small" ).addClass( "active" );
        $( ".button--like-to, .like-to" ).removeClass( "active" );
        $( ".bg-overlay" ).addClass( "active" );
      }
    } );

    ///////////////////////////////////////////
    // Mobile overlay display
    ///////////////////////////////////////////

    $( ".bg-overlay" ).click( function() {

      // Close mega menu
      $( ".site-header--nav li a, .site-header__dropdowns__item" ).removeClass( "active" );

      // Close mobile I"d like menu
      $( ".button--like-to, .like-to" ).removeClass( "active" );

      // Close mobile search
      $( ".button--search--small, .search--small" ).removeClass( "active" );

      // Fade out overlay
      $( this ).removeClass( "active" );
    } );

    ///////////////////////////////////////////
    // Show health system stats on page scroll
    ///////////////////////////////////////////
    $(".js-fadeInElement").each(function(){
      var $el = $(this);

      // is the page scrollable
      if($('body').innerHeight() > window.innerHeight){
        fadeElement($el);
      }
      $(window).scroll( function() {
        fadeElement($el);
      });
      function fadeElement($el){
        var elementTopToPageTop = $el.offset().top;
        var windowTopToPageTop = $(window).scrollTop();
        var windowInnerHeight = window.innerHeight;
        var elementTopToWindowTop = elementTopToPageTop - windowTopToPageTop;
        var elementTopToWindowBottom = windowInnerHeight - elementTopToWindowTop;
        var distanceFromBottomToAppear = 300;

        if ( elementTopToWindowBottom > distanceFromBottomToAppear ) {
          $el.addClass( "health-system__stats--show" );
        } else if ( elementTopToWindowBottom < 0 ) {
          $el.removeClass( "health-system__stats--show" );
          $el.addClass( "health-system__stats--hide" );
        }
      }
    });  // End show health sytem stats

  } );

} )( jQuery );
