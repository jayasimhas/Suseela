function initMap(){
	let googleMap = document.querySelectorAll('.js-gmap');

	for(let i=0;i < googleMap.length; i++){
		let element = googleMap[i],
			lat = element.getAttribute('data-lat'),
			lng = element.getAttribute('data-lng'),
			canvas = element.querySelectorAll('.js-gmap-canvas')[0],
			infoWindowHtml = element.querySelectorAll('.js-gmap-info-window')[0].innerHTML,
			myOptions = {},
			map,
			marker,
			infowindow;

		myOptions = {
			zoom: 15,
			center: new google.maps.LatLng(lat, lng),
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};

		map = new google.maps.Map(canvas, myOptions);
		marker = new google.maps.Marker({ map: map, position: new google.maps.LatLng(lat, lng) });
		infowindow = new google.maps.InfoWindow({ content: infoWindowHtml });
		google.maps.event.addListener(marker, "click", function() { infowindow.open(map, marker); });

	}
}
function addGoogleMapJS(){
	var scriptTag = document.createElement('script'), 
		scripts = document.scripts[0];

	// Add the Google Maps API JS file
	scriptTag.src = '//maps.google.com/maps/api/js?sensor=false';
	scriptTag.onload = () => initMap();
	scripts.parentNode.insertBefore(scriptTag, scripts);
}

function init(){
	let googleMap = document.querySelector('.js-gmap');

	if (null === googleMap){
		return;
	}

	addGoogleMapJS();
}

export default {
	init: init
}